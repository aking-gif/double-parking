# MA Dashboard — أرسان للتشغيل

لوحة إجراءات إدارة المشاريع.

## النشر على GitHub Pages

1. ارفع هذا المجلد إلى فرع `main`
2. Settings → Pages → Source: `Deploy from a branch` → `main` / `root`
3. الرابط سيكون: https://aking-gif.github.io/double-parking/
